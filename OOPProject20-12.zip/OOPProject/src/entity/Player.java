package entity;

import main.GamePanel;
import main.KeyHandler;
import java.awt.Graphics2D;
import java.io.IOException;
import java.awt.image.BufferedImage;
// import java.io.*;

import javax.imageio.ImageIO;

import java.awt.Color;

public class Player extends Entity {
    GamePanel gp;
    KeyHandler keyH;

    public Player(){
        super(150, 50, 4, 0, -12, "down");
    }
    public Player(GamePanel gp, KeyHandler keyH) {
        super(150, 50, 4, 0, -12, "down");
        this.gp = gp;
        this.keyH = keyH;

        getPlayerImage();
    }

    public void getPlayerImage() {
        try {
            up1 = ImageIO.read(getClass().getResourceAsStream("/player/test0.png"));
            up2 = ImageIO.read(getClass().getResourceAsStream("/player/test2.png"));
            down1 = ImageIO.read(getClass().getResourceAsStream("/player/test0.png"));
            down2 = ImageIO.read(getClass().getResourceAsStream("/player/test2.png"));
            left1 = ImageIO.read(getClass().getResourceAsStream("/player/test0.png"));
            left2 = ImageIO.read(getClass().getResourceAsStream("/player/test2.png"));
            right1 = ImageIO.read(getClass().getResourceAsStream("/player/test0.png"));
            right2 = ImageIO.read(getClass().getResourceAsStream("/player/test2.png"));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void update() {
        // fall
        this.setFallSpeed(this.getFallSpeed() + 0.2);
        this.setY(this.getY() + this.getFallSpeed());

        if (this.getY() > 500) {
            this.setFallSpeed(-10);
        }
        // key
        if (keyH.upPressed == true) {
            this.setDirection("up");
            this.setY(this.getY() - this.getFallSpeed());
        } else if (keyH.downPressed == true) {
            this.setDirection("down");
            this.setY(this.getY() + this.getFallSpeed());
        } else if (keyH.leftPressed == true) {
            this.setDirection("left");
            this.setX(this.getX() - this.getSpeed());
        } else if (keyH.rightPressed == true) {
            this.setDirection("right");
            this.setX(this.getX() + this.getSpeed());
        }

        spriteCounter++;

        if (spriteCounter > 12) {
            if (spriteNum == 1) {
                spriteNum = 2;
            } else if (spriteNum == 2) {
                spriteNum = 1;
            }
            spriteCounter = 0;
        }
    }

    public void draw(Graphics2D g2) {
        g2.setColor(Color.white);
        g2.fillRect((int) this.getX(), (int) this.getY(), gp.tileSize, gp.tileSize);
        BufferedImage image = null;
        switch (this.getDirection()) {
            case "up":
                if (spriteNum == 1) {
                    image = up1;
                }
                if (spriteNum == 2) {
                    image = up2;
                }
                break;
            case "down":
                if (spriteNum == 1) {
                    image = down1;
                }
                if (spriteNum == 2) {
                    image = down2;
                }
                break;
            case "left":
                if (spriteNum == 1) {
                    image = left1;
                }
                if (spriteNum == 2) {
                    image = left2;
                }
                break;
            case "right":
                if (spriteNum == 1) {
                    image = right1;
                }
                if (spriteNum == 2) {
                    image = right2;
                }
                break;
        }
        g2.drawImage(image, (int) this.getX(), (int) this.getY(), gp.tileSize, gp.tileSize, null);
    }
}
