package entity;

import main.GamePanel;
// import main.KeyHandler;
import java.awt.Graphics2D;
// import java.util.Random;
// import java.awt.Color;

// import java.util.random.*;

public class Platforms extends Entity {
    GamePanel gp;
    Player player;
    public Platforms[] platformsPosition;
    
    public Platforms() {
        super(100, 100, 150, "/object/platform.png", "/object/slime1.png");
    }

    public Platforms(GamePanel gp, Player player) {
        super(100, 100, 150, "/object/platform.png", "/object/slime1.png");
        this.gp = gp;
        this.player = player;
        getPlatformImage();
    }

    public void start() {
        platformsPosition = new Platforms[20];

        for (int i = 0; i < 6; i++) {
            platformsPosition[i] = new Platforms();
            platformsPosition[i].setX((int) (Math.random() * (400 - platform.getWidth())));
            // platformsPosition[i].x = new Random().nextInt(300);
            // platformsPosition[i].y = new Random().nextInt(533);
            platformsPosition[i].setY(((int) (Math.random() * 50) + 50) * i);
            System.out.println("platform" + platformsPosition[i].getX());
            System.out.println("platform" + platformsPosition[i].getY());
        }
    }

    public void update() {
        this.isOnPlatform();
        this.genNextScreen();
    }

    public void draw(Graphics2D g2) {
        for (int i = 0; i < 6; i++) {
            g2.drawImage(
                    platform,
                    (int) platformsPosition[i].getX(),
                    (int) platformsPosition[i].getY(),
                    platform.getWidth(),
                    platform.getHeight(),
                    null);
        }
    }

    public void isOnPlatform(){
        for (int i = 0; i < 6; i++) {
            if ((player.getX() + 35 > platformsPosition[i].getX()) &&
                    (player.getX() + 10 < platformsPosition[i].getX() + 68) &&
                    (player.getY() + 55 > platformsPosition[i].getY()) &&
                    (player.getY() + 55 < platformsPosition[i].getY() + 14) &&
                    (player.getY() > 0) && player.getFallSpeed() >= 0) {
                player.setFallSpeed(player.getJumpHeight());
                // System.out.println(player.x);
               
                gp.playSE(5);
                // System.out.println(h);
            }
            if(player.getY() >= 502){
                System.out.println("Game Over!!!!");
                player.setX(200);
                player.setY(50);
                // gp.gameOver();
                gp.gameState = gp.gameoverState;
                gp.stopMusic();
            }
        }
    }

    public void genNextScreen(){
        if (player.getY() < this.getH()) {
            for (int i = 0; i < 6; i++) {
                player.setY(this.getH());
                platformsPosition[i].setY(platformsPosition[i].getY() - (int) player.getFallSpeed());
                if (platformsPosition[i].getY() > 533) {
                    // platformsPosition[i].y = 0;
                    platformsPosition[i].setY(((int) (Math.random() * 50) - 50));
                    // platformsPosition[i].x = new Random().nextInt(300);
                    platformsPosition[i].setX((int) (Math.random() * (400 - platform.getWidth())));
                    gp.setScore(gp.getScore()+10);
                    System.out.println("platformnext" + platformsPosition[i].getX());
            System.out.println("platformnext" + platformsPosition[i].getY());
            System.out.println("platformnext" + platformsPosition[i].getH());
                }
            }
        }
    }
}