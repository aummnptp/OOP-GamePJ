package entity;

import main.GamePanel;
// import main.KeyHandler;
import java.awt.Graphics2D;
import java.util.Random;
// import java.awt.Color;

// import java.util.random.*;

public class Spikes extends Entity {
    GamePanel gp;
    Player player;
    Platforms platforms;
    public Spikes[] spikesPosition;

    public Spikes() {
        super(100, 100, 150, "/object/platform.png", "/object/slime1.png");
    }

    public Spikes(GamePanel gp, Player player, Platforms platforms) {
        super(100, 100, 150, "/object/platform.png", "/object/slime1.png");
        this.gp = gp;
        this.player = player;
        this.platforms = platforms;
        getSpikeImage();
    }

    public void start() {
        spikesPosition = new Spikes[20];

        for (int i = 0; i < 2; i++) {
            spikesPosition[i] = new Spikes();
            // spikesPosition[i].setX((int) (Math.random() * (400 - spike.getWidth())));
            spikesPosition[i].setX(new Random().nextInt(300));
            spikesPosition[i].setY(new Random().nextInt(500));
            // spikesPosition[i].setY(((int) (Math.random() * 50) + 50) * i);
            
        }
    }

    public void update() {
        this.isOnSpike();
        this.genNextScreen();
    }

    public void draw(Graphics2D g2) {
        for (int i = 0; i < 2; i++) {
            g2.drawImage(
                    spike,
                    (int) spikesPosition[i].getX(),
                    (int) spikesPosition[i].getY(),
                    spike.getWidth(),
                    spike.getHeight(),
                    null);
        }
    }

    public void isOnSpike(){
        for (int i = 0; i < 2; i++) {
            if ((player.getX() + 35 > spikesPosition[i].getX()) &&
                    (player.getX() + 10 < spikesPosition[i].getX() + 68) &&
                    (player.getY() + 55 > spikesPosition[i].getY()) &&
                    (player.getY() + 55 < spikesPosition[i].getY() + 14) &&
                    (player.getY() > 0) && player.getFallSpeed() >= 0) {
                player.setFallSpeed(player.getJumpHeight());
                System.out.println("gameOver");
                // System.out.println(player.x);
                gp.playSE(1);
                // System.out.println(h);
            }
            if(player.getY() >= 502){
                System.out.println("Game Over!!!!");
                player.setX(200);
                player.setY(50);
                gp.gameOver();
            }
        }
    }

    public void genNextScreen(){
        if (player.getY() < platforms.getH()) {
            for (int i = 0; i < 2; i++) {
                player.setY(platforms.getH());
                spikesPosition[i].setY(spikesPosition[i].getY() - (int) player.getFallSpeed());
                if (platforms.platformsPosition[i].getY() > 533) {
                    // spikesPosition[i].y = 0;
                    spikesPosition[i].setY(((int) (Math.random() * 50) - 50));
                    // spikesPosition[i].x = new Random().nextInt(300);
                    spikesPosition[i].setX((int) (Math.random() * (400 - spike.getWidth())));
                    
                }
            }
            
        }
    }
}
